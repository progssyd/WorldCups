﻿using System.ComponentModel.DataAnnotations;

namespace WorldCups.Models
{
    public class CategorisTransportation
    {
        [Key]
        public int Id { get; set; }  
        public string Name { get; set; } //seedan jeep small 

    }
}
