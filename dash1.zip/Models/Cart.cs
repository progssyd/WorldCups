﻿namespace WorldCups.Models
{
    public class Cart
    {
        public int Id { get; set; }
        public int Productid { get; set; }
        public int Count { get; set; }
    }
}
